//******************************************************************************
//* Includes
//******************************************************************************
#include "UnityRobot.h"
#include "AnalogPin.h"


//******************************************************************************
//* Constructors
//******************************************************************************

AnalogPin::AnalogPin(int id, int pin) : UnityModule(id, false)
{
	_pin = pin;
}


//******************************************************************************
//* Override Methods
//******************************************************************************
void AnalogPin::OnSetup()
{
}

void AnalogPin::OnStart()
{
}

void AnalogPin::OnStop()
{	
}

void AnalogPin::OnProcess()
{	
}

void AnalogPin::OnUpdate()
{
}

void AnalogPin::OnAction()
{
}

void AnalogPin::OnFlush()
{
	UnityRobot.push((word)analogRead(_pin));
}
