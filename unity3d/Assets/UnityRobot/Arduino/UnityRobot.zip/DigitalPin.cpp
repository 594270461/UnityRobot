//******************************************************************************
//* Includes
//******************************************************************************
#include "UnityRobot.h"
#include "DigitalPin.h"


//******************************************************************************
//* Constructors
//******************************************************************************

DigitalPin::DigitalPin(int id, int pin) : UnityModule(id, false)
{
	_pin = pin;
	_mode = 0; // output
}

//******************************************************************************
//* Override Methods
//******************************************************************************
void DigitalPin::OnSetup()
{
	setMode();
	if(_mode == 0) // output
	{
		_state = 0;
		digitalWrite(_pin, _state);
	}
	else if(_mode == 3) // pwm
	{
		_state = 0;
		analogWrite(_pin, _state);
	}
}

void DigitalPin::OnStart()
{
}

void DigitalPin::OnStop()
{
	if(_mode == 0) // output
	{
		_state = 0;
		digitalWrite(_pin, _state);
	}
	else if(_mode == 3) // pwm
	{
		_state = 0;
		analogWrite(_pin, _state);
	}
}

void DigitalPin::OnProcess()
{	
}

void DigitalPin::OnUpdate()
{
	byte newMode;	
	UnityRobot.pop(&newMode);
	if(_mode != newMode)
	{
		_mode = newMode;
		setMode();
	}

	if(_mode == 0 || _mode == 3) // output or pwm
	{
		byte newState;
		UnityRobot.pop(&newState);
		if(_state != newState)
			_state = newState;
	}
}

void DigitalPin::OnAction()
{
	if(_mode == 0) // output
		digitalWrite(_pin, _state);
	else if(_mode == 3) // pwm
		analogWrite(_pin, _state);
}

void DigitalPin::OnFlush()
{
	if(_mode == 1 || _mode == 2) // input or input_pullup
	{
		_state = digitalRead(_pin);
		UnityRobot.push(_state);
	}
}

//******************************************************************************
//* Private Methods
//******************************************************************************

void DigitalPin::setMode()
{
	if(_mode == 0)
	{
		pinMode(_pin, OUTPUT);
		_outputOnly = true;
	}
	else if(_mode == 1)
	{
		pinMode(_pin, INPUT);
		_outputOnly = false;
	}
	else if(_mode == 2)
	{
		pinMode(_pin, INPUT_PULLUP);
		_outputOnly = false;
	}
	else if(_mode == 3) // pwm
	{
		_outputOnly = true;
	}
}
