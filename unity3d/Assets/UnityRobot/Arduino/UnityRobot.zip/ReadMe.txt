[Informations]
Guide Link(https://sites.google.com/site/unityrobotguide/)
All right reserved Idealink(http://www.idealink.kr)
[Release Note]
*v1.0.0b5 (November/21/2014)
<Arduino>
 -
<Unity3D>
 -[Add]AnalogPinDrag
<PlayMakerNGUI>
 -[Add]UnityModuleEvent
 -[Add]AnalogPinDragEvent
 -[Add]Template_UnityModule
 -[Add]Template_AnalogPinDrag
 -[Add]Example for Pot_RotatingObject
 -[Add]Example for Pot_BallDefence
 -[Add]Example for Pot_ProgressControl
 -[Add]Example for SoftPot_ScalingObject
 -[Add]Example for SoftPot_MultiButton
 -[Add]Example for SoftPot_DraggingObject
 -[Add]Example for SoftPot_ScrollbarControl