#ifndef AnalogPin_h
#define AnalogPin_h

#include "UnityModule.h"


class AnalogPin : UnityModule
{
public:
	AnalogPin(int id, int pin);

protected:
	void OnSetup();
	void OnStart();
	void OnStop();
	void OnProcess();
	void OnUpdate();
	void OnAction();
	void OnFlush();

private:
    int _pin;
};

#endif

